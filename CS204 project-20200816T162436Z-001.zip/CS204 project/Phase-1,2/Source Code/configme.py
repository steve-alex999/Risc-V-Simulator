breakflag=0
